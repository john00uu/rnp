# from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Request, Response
# from fastapi.responses import JSONResponse, FileResponse, HTMLResponse
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.staticfiles import StaticFiles
# from fastapi.security import HTTPBasic, HTTPBasicCredentials
# import psycopg2
# import psycopg2.extras
# import json
# import os
# import secrets
# import pandas as pd
# from io import BytesIO
# from typing import List, Dict, Any, Optional
# import base64
# from datetime import datetime

# # Initialize FastAPI app
# app = FastAPI(title="RNP Data Management System")

# # Add CORS middleware
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Mount static files
# app.mount("/static", StaticFiles(directory="static"), name="static")

# # Security
# security = HTTPBasic()

# # Database connection parameters - Updated for RNP database
# DB_HOST = os.environ.get("DB_HOST", "10.13.44.80")
# DB_PORT = os.environ.get("DB_PORT", "5432")
# DB_NAME = os.environ.get("DB_NAME", "RNP")  # Updated to RNP
# DB_USER = os.environ.get("DB_USER", "postgres")
# DB_PASS = os.environ.get("DB_PASS", "P@ssw0rd")

# # User credentials (in a real app, these would be stored in a database with hashed passwords)
# USERS = {
#     "admin": "password123",
#     "user": "user123"
# }

# # Default columns to display if user has no preferences
# DEFAULT_COLUMNS = ["SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status"]

# # Database connection function
# def get_db_connection():
#     try:
#         conn = psycopg2.connect(
#             host=DB_HOST,
#             port=DB_PORT,
#             database=DB_NAME,
#             user=DB_USER,
#             password=DB_PASS
#         )
#         return conn
#     except Exception as e:
#         print(f"Database connection error: {e}")
#         raise HTTPException(status_code=500, detail=f"Database connection error: {str(e)}")

# # Authentication function
# def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
#     correct_password = USERS.get(credentials.username)
#     if not correct_password:
#         raise HTTPException(
#             status_code=401,
#             detail="Invalid username",
#             headers={"WWW-Authenticate": "Basic"},
#         )
    
#     is_correct_password = secrets.compare_digest(
#         credentials.password, correct_password
#     )
#     if not is_correct_password:
#         raise HTTPException(
#             status_code=401,
#             detail="Invalid password",
#             headers={"WWW-Authenticate": "Basic"},
#         )
    
#     return credentials.username

# # Root endpoint - serve the main HTML page
# @app.get("/", response_class=HTMLResponse)
# async def get_root():
#     return FileResponse("static/index.html")

# # Login endpoint
# # @app.post("/login")
# # async def login(credentials: HTTPBasicCredentials = Depends(security)):
# #     username = get_current_username(credentials)
# #     return {"username": username, "message": "Login successful"}

# # Get user preferences

# @app.get("/user/preferences")
# async def get_user_preferences(username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
#         # Check if user_preferences table exists
#         cursor.execute("""
#             SELECT EXISTS (
#                 SELECT FROM information_schema.tables 
#                 WHERE table_name = 'user_preferences'
#             )
#         """)
#         table_exists = cursor.fetchone()['exists']
        
#         if not table_exists:
#             # Create user_preferences table if it doesn't exist
#             cursor.execute("""
#                 CREATE TABLE user_preferences (
#                     username TEXT PRIMARY KEY,
#                     columns TEXT[]
#                 )
#             """)
#             conn.commit()
        
#         # Get user preferences
#         cursor.execute("SELECT columns FROM user_preferences WHERE username = %s", (username,))
#         result = cursor.fetchone()
        
#         if result:
#             return {"columns": result['columns']}
#         else:
#             # Return default columns if no preferences are found
#             return {"columns": DEFAULT_COLUMNS}
#     except Exception as e:
#         print(f"Error getting user preferences: {e}")
#         return {"columns": DEFAULT_COLUMNS}
#     finally:
#         conn.close()

# # Update user preferences
# @app.post("/user/preferences")
# async def update_user_preferences(preferences: Dict[str, List[str]], username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor()
        
#         # Check if user_preferences table exists
#         cursor.execute("""
#             SELECT EXISTS (
#                 SELECT FROM information_schema.tables 
#                 WHERE table_name = 'user_preferences'
#             )
#         """)
#         table_exists = cursor.fetchone()[0]
        
#         if not table_exists:
#             # Create user_preferences table if it doesn't exist
#             cursor.execute("""
#                 CREATE TABLE user_preferences (
#                     username TEXT PRIMARY KEY,
#                     columns TEXT[]
#                 )
#             """)
        
#         # Upsert user preferences
#         cursor.execute("""
#             INSERT INTO user_preferences (username, columns)
#             VALUES (%s, %s)
#             ON CONFLICT (username) 
#             DO UPDATE SET columns = EXCLUDED.columns
#         """, (username, preferences["columns"]))
        
#         conn.commit()
#         return {"message": "Preferences updated successfully"}
#     except Exception as e:
#         conn.rollback()
#         raise HTTPException(status_code=500, detail=f"Error updating preferences: {str(e)}")
#     finally:
#         conn.close()

# # Get all column names
# @app.get("/columns")
# async def get_columns(username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor()
        
#         # Check if tracker table exists
#         cursor.execute("""
#             SELECT EXISTS (
#                 SELECT FROM information_schema.tables 
#                 WHERE table_name = 'tracker'
#             )
#         """)
#         table_exists = cursor.fetchone()[0]
        
#         if not table_exists:
#             # Create a sample tracker table with minimal columns for testing
#             cursor.execute("""
#                 CREATE TABLE tracker (
#                     "SITE_ID" TEXT PRIMARY KEY,
#                     "Site Name" TEXT,
#                     "DISTRICT_COMMUNITY" TEXT,
#                     "City/Road" TEXT,
#                     "Economical Region" TEXT,
#                     "Lat" NUMERIC,
#                     "Long" NUMERIC,
#                     "Planning Status" TEXT
#                 )
#             """)
#             conn.commit()
            
#             # Insert some sample data
#             sample_data = [
#                 ('SITE001', 'Alpha Site', 'District A', 'Main Road', 'North', 40.7128, -74.0060, 'Active'),
#                 ('SITE002', 'Beta Site', 'District B', 'Secondary Road', 'South', 34.0522, -118.2437, 'Planning'),
#                 ('SITE003', 'Gamma Site', 'District C', 'Highway 1', 'East', 41.8781, -87.6298, 'Construction'),
#                 ('SITE004', 'Delta Site', 'District A', 'Avenue X', 'West', 29.7604, -95.3698, 'Active'),
#                 ('SITE005', 'Epsilon Site', 'District D', 'Boulevard Y', 'Central', 39.9526, -75.1652, 'Maintenance')
#             ]
            
#             cursor.executemany("""
#                 INSERT INTO tracker ("SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status")
#                 VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
#             """, sample_data)
#             conn.commit()
        
#         cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'tracker' ORDER BY ordinal_position")
#         columns = [row[0] for row in cursor.fetchall()]
#         return {"columns": columns}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error fetching columns: {str(e)}")
#     finally:
#         conn.close()

# # Get paginated data
# @app.get("/data")
# async def get_data(offset: int = 0, limit: int = 50, columns: Optional[str] = None, search: Optional[str] = None, username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
#         # Determine which columns to fetch
#         if columns:
#             column_list = columns.split(",")
#         else:
#             # Get user preferences
#             cursor.execute("SELECT columns FROM user_preferences WHERE username = %s", (username,))
#             result = cursor.fetchone()
            
#             if result:
#                 column_list = result['columns']
#             else:
#                 column_list = DEFAULT_COLUMNS
        
#         # Ensure we always include SITE_ID for reference
#         if "SITE_ID" not in column_list:
#             column_list.insert(0, "SITE_ID")
        
#         columns_sql = ", ".join(f'"{col}"' for col in column_list)
        
#         # Build the query
#         query = f'SELECT {columns_sql} FROM tracker'
#         params = []
        
#         # Add search condition if provided
#         if search:
#             search_conditions = []
#             for col in column_list:
#                 search_conditions.append(f'"{col}"::text ILIKE %s')
#                 params.append(f'%{search}%')
            
#             query += " WHERE " + " OR ".join(search_conditions)
        
#         # Add pagination
#         query += " ORDER BY \"SITE_ID\" LIMIT %s OFFSET %s"
#         params.extend([limit, offset])
        
#         cursor.execute(query, params)
#         data = cursor.fetchall()
        
#         # Get total count for pagination info
#         cursor.execute("SELECT COUNT(*) FROM tracker")
#         total = cursor.fetchone()["count"]
        
#         return {
#             "data": data,
#             "total": total,
#             "offset": offset,
#             "limit": limit,
#             "has_more": offset + limit < total
#         }
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error fetching data: {str(e)}")
#     finally:
#         conn.close()

# # Get all data (for expanding row details)
# @app.get("/data/all")
# async def get_all_data(site_id: str, username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
#         cursor.execute('SELECT * FROM tracker WHERE "SITE_ID" = %s', (site_id,))
#         data = cursor.fetchone()
        
#         if not data:
#             raise HTTPException(status_code=404, detail=f"Site with ID {site_id} not found")
        
#         return data
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error fetching data: {str(e)}")
#     finally:
#         conn.close()

# # Edit data
# @app.post("/data/edit")
# async def edit_data(data: Dict[str, Dict[str, Any]], username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor()
        
#         # Begin transaction
#         conn.autocommit = False
        
#         for site_id, updates in data.items():
#             # Build SET clause for UPDATE statement
#             set_clause = ", ".join([f'"{col}" = %s' for col in updates.keys()])
#             values = list(updates.values())
#             values.append(site_id)  # For the WHERE clause
            
#             query = f'UPDATE tracker SET {set_clause} WHERE "SITE_ID" = %s'
#             cursor.execute(query, values)
        
#         # Commit transaction
#         conn.commit()
        
#         return {"message": "Data updated successfully"}
#     except Exception as e:
#         # Rollback in case of error
#         conn.rollback()
#         raise HTTPException(status_code=500, detail=f"Error updating data: {str(e)}")
#     finally:
#         conn.autocommit = True
#         conn.close()

# # Import data from Excel

# @app.post("/data/import")
# async def import_data(file: UploadFile = File(...), username: str = Depends(get_current_username)):
#     if not file.filename.endswith(('.xlsx', '.xls')):
#         raise HTTPException(status_code=400, detail="Only Excel files are allowed")
    
#     try:
#         # Read Excel file
#         contents = await file.read()
#         df = pd.read_excel(BytesIO(contents))
        
#         # Ensure SITE_ID column exists
#         if "SITE_ID" not in df.columns:
#             raise HTTPException(status_code=400, detail="Excel file must contain a SITE_ID column")
        
#         conn = get_db_connection()
#         try:
#             cursor = conn.cursor()
            
#             # Begin transaction
#             conn.autocommit = False
            
#             # Get existing columns from database
#             cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'tracker'")
#             db_columns = [row[0] for row in cursor.fetchall()]
            
#             # Filter dataframe to only include columns that exist in the database
#             valid_columns = [col for col in df.columns if col in db_columns]
#             df_filtered = df[valid_columns]
            
#             # Process each row
#             for _, row in df_filtered.iterrows():
#                 site_id = row["SITE_ID"]
                
#                 # Check if the site exists
#                 cursor.execute('SELECT 1 FROM tracker WHERE "SITE_ID" = %s', (site_id,))
#                 site_exists = cursor.fetchone() is not None
                
#                 # Convert row to dict and handle NaN values
#                 row_dict = row.to_dict()
#                 for k, v in row_dict.items():
#                     if pd.isna(v):
#                         row_dict[k] = None
                
#                 if site_exists:
#                     # Update existing site
#                     set_clause = ", ".join([f'"{col}" = %s' for col in valid_columns if col != "SITE_ID"])
#                     values = [row_dict[col] for col in valid_columns if col != "SITE_ID"]
#                     values.append(site_id)  # For the WHERE clause
                    
#                     if set_clause:  # Only proceed if there are columns to update
#                         query = f'UPDATE tracker SET {set_clause} WHERE "SITE_ID" = %s'
#                         cursor.execute(query, values)
#                 else:
#                     # Insert new site
#                     columns = ", ".join([f'"{col}"' for col in valid_columns])
#                     placeholders = ", ".join(["%s"] * len(valid_columns))
#                     values = [row_dict[col] for col in valid_columns]
                    
#                     query = f'INSERT INTO tracker ({columns}) VALUES ({placeholders})'
#                     cursor.execute(query, values)
            
#             # Commit transaction
#             conn.commit()
            
#             return {"message": f"Successfully imported {len(df)} rows"}
#         except Exception as e:
#             # Rollback in case of error
#             conn.rollback()
#             raise HTTPException(status_code=500, detail=f"Error importing data: {str(e)}")
#         finally:
#             conn.autocommit = True
#             conn.close()
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

# # Export data to Excel
# @app.get("/data/export")
# async def export_data(columns: Optional[str] = None, search: Optional[str] = None, username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
#         # Determine which columns to fetch
#         if columns:
#             column_list = columns.split(",")
#         else:
#             # Get all columns for export
#             cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'tracker' ORDER BY ordinal_position")
#             column_list = [row["column_name"] for row in cursor.fetchall()]
        
#         columns_sql = ", ".join(f'"{col}"' for col in column_list)
        
#         # Build the query
#         query = f'SELECT {columns_sql} FROM tracker'
#         params = []
        
#         # Add search condition if provided
#         if search:
#             search_conditions = []
#             for col in column_list:
#                 search_conditions.append(f'"{col}"::text ILIKE %s')
#                 params.append(f'%{search}%')
            
#             query += " WHERE " + " OR ".join(search_conditions)
        
#         cursor.execute(query, params)
#         data = cursor.fetchall()
        
#         # Convert to DataFrame and export to Excel
#         df = pd.DataFrame(data)
        
#         # Create a BytesIO object to store the Excel file
#         output = BytesIO()
#         with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
#             df.to_excel(writer, index=False, sheet_name='Data')
        
#         # Generate a unique filename
#         timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#         filename = f"data_export_{timestamp}.xlsx"
        
#         # Create exports directory if it doesn't exist
#         os.makedirs("static/exports", exist_ok=True)
        
#         # Create the Excel file on disk
#         output.seek(0)
#         with open(f"static/exports/{filename}", "wb") as f:
#             f.write(output.getvalue())
        
#         # Return the download URL
#         return {"download_url": f"/static/exports/{filename}"}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error exporting data: {str(e)}")
#     finally:
#         conn.close()

# # Add a new site
# @app.post("/data/add")
# async def add_site(site_data: Dict[str, Any], username: str = Depends(get_current_username)):
#     if "SITE_ID" not in site_data:
#         raise HTTPException(status_code=400, detail="SITE_ID is required")
    
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor()
        
#         # Check if site already exists
#         cursor.execute('SELECT 1 FROM tracker WHERE "SITE_ID" = %s', (site_data["SITE_ID"],))
#         if cursor.fetchone():
#             raise HTTPException(status_code=400, detail=f"Site with ID {site_data['SITE_ID']} already exists")
        
#         # Insert new site
#         columns = ", ".join([f'"{col}"' for col in site_data.keys()])
#         placeholders = ", ".join(["%s"] * len(site_data))
#         values = list(site_data.values())
        
#         query = f'INSERT INTO tracker ({columns}) VALUES ({placeholders})'
#         cursor.execute(query, values)
#         conn.commit()
        
#         return {"message": "Site added successfully"}
#     except Exception as e:
#         conn.rollback()
#         raise HTTPException(status_code=500, detail=f"Error adding site: {str(e)}")
#     finally:
#         conn.close()

# # Delete a site
# @app.delete("/data/delete/{site_id}")
# async def delete_site(site_id: str, username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor()
        
#         # Check if site exists
#         cursor.execute('SELECT 1 FROM tracker WHERE "SITE_ID" = %s', (site_id,))
#         if not cursor.fetchone():
#             raise HTTPException(status_code=404, detail=f"Site with ID {site_id} not found")
        
#         # Delete site
#         cursor.execute('DELETE FROM tracker WHERE "SITE_ID" = %s', (site_id,))
#         conn.commit()
        
#         return {"message": f"Site {site_id} deleted successfully"}
#     except Exception as e:
#         conn.rollback()
#         raise HTTPException(status_code=500, detail=f"Error deleting site: {str(e)}")
#     finally:
#         conn.close()

# # Get statistics
# @app.get("/stats")
# async def get_stats(username: str = Depends(get_current_username)):
#     conn = get_db_connection()
#     try:
#         cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
#         # Get total count
#         cursor.execute("SELECT COUNT(*) as total FROM tracker")
#         total = cursor.fetchone()["total"]
        
#         # Get counts by planning status
#         cursor.execute("""
#             SELECT "Planning Status", COUNT(*) as count 
#             FROM tracker 
#             GROUP BY "Planning Status"
#         """)
#         status_counts = cursor.fetchall()
        
#         # Get counts by region
#         cursor.execute("""
#             SELECT "Economical Region", COUNT(*) as count 
#             FROM tracker 
#             GROUP BY "Economical Region"
#         """)
#         region_counts = cursor.fetchall()
        
#         return {
#             "total_sites": total,
#             "by_status": status_counts,
#             "by_region": region_counts
#         }
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error fetching statistics: {str(e)}")
#     finally:
#         conn.close()

# # Initialize database tables if they don't exist
# # @app.on_event("startup")
# # async def startup_event():
# #     # Create exports directory if it doesn't exist
# #     os.makedirs("static/exports", exist_ok=True)
    
# #     conn = get_db_connection()
# #     try:
# #         cursor = conn.cursor()
        
# #         # Check if user_preferences table exists
# #         cursor.execute("""
# #             SELECT EXISTS (
# #                 SELECT FROM information_schema.tables 
# #                 WHERE table_name = 'user_preferences'
# #             )
# #         """)
# #         table_exists = cursor.fetchone()[0]
        
# #         if not table_exists:
# #             # Create user_preferences table
# #             cursor.execute("""
# #                 CREATE TABLE user_preferences (
# #                     username TEXT PRIMARY KEY,
# #                     columns TEXT[]
# #                 )
# #             """)
# #             conn.commit()
# #             print("Created user_preferences table")
        
# #         # Check if tracker table exists
# #         cursor.execute("""
# #             SELECT EXISTS (
# #                 SELECT FROM information_schema.tables 
# #                 WHERE table_name = 'tracker'
# #             )
# #         """)
# #         table_exists = cursor.fetchone()[0]
        
# #         if not table_exists:
# #             # Create a minimal tracker table for testing
# #             cursor.execute("""
# #                 CREATE TABLE tracker (
# #                     "SITE_ID" TEXT PRIMARY KEY,
# #                     "Site Name" TEXT,
# #                     "DISTRICT_COMMUNITY" TEXT,
# #                     "City/Road" TEXT,
# #                     "Economical Region" TEXT,
# #                     "Lat" NUMERIC,
# #                     "Long" NUMERIC,
# #                     "Planning Status" TEXT
# #                 )
# #             """)
# #             conn.commit()
            
# #             # Insert some sample data
# #             sample_data = [
# #                 ('SITE001', 'Alpha Site', 'District A', 'Main Road', 'North', 40.7128, -74.0060, 'Active'),
# #                 ('SITE002', 'Beta Site', 'District B', 'Secondary Road', 'South', 34.0522, -118.2437, 'Planning'),
# #                 ('SITE003', 'Gamma Site', 'District C', 'Highway 1', 'East', 41.8781, -87.6298, 'Construction'),
# #                 ('SITE004', 'Delta Site', 'District A', 'Avenue X', 'West', 29.7604, -95.3698, 'Active'),
# #                 ('SITE005', 'Epsilon Site', 'District D', 'Boulevard Y', 'Central', 39.9526, -75.1652, 'Maintenance')
# #             ]
            
# #             cursor.executemany("""
# #                 INSERT INTO tracker ("SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status")
# #                 VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
# #             """, sample_data)
# #             conn.commit()
# #             print("Created tracker table with sample data")
# #     except Exception as e:
# #         print(f"Error initializing database: {e}")
# #     finally:
# #         conn.close()

# # Run the application
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)


from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Request, Response
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import psycopg2
import psycopg2.extras
import json
import os
import secrets
import pandas as pd
from io import BytesIO
from typing import List, Dict, Any, Optional
import base64
from datetime import datetime

# Initialize FastAPI app
app = FastAPI(title="RNP Data Management System")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Security
security = HTTPBasic()

# Database connection parameters - Updated for RNP database
DB_HOST = os.environ.get("DB_HOST", "10.13.44.80")
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ.get("DB_NAME", "RNP")  # Updated o RNP
DB_USER = os.environ.get("DB_USER", "postgres")
DB_PASS = os.environ.get("DB_PASS", "P@ssw0rd")

# User credentials (in a real app, these would be stored in a database with hashed passwords)
USERS = {
    "admin": "password123",
    "user": "user123"
}

# Default columns to display if user has no preferences
DEFAULT_COLUMNS = ["SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status"]

# Database connection function
def get_db_connection():
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASS
        )
        return conn
    except Exception as e:
        print(f"Database connection error: {e}")
        raise HTTPException(status_code=500, detail=f"Database connection error: {str(e)}")

# Authentication function
def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    correct_password = USERS.get(credentials.username)
    if not correct_password:
        raise HTTPException(
            status_code=401,
            detail="Invalid username",
            headers={"WWW-Authenticate": "Basic"},
        )
    
    is_correct_password = secrets.compare_digest(
        credentials.password, correct_password
    )
    if not is_correct_password:
        raise HTTPException(
            status_code=401,
            detail="Invalid password",
            headers={"WWW-Authenticate": "Basic"},
        )
    
    return credentials.username

# Root endpoint - serve the main HTML page
@app.get("/", response_class=HTMLResponse)
async def get_root():
    return FileResponse("static/index.html")

# Add this route to bypass authentication for testing
@app.post("/api/login")
async def login_bypass(request: Request):
    data = await request.json()
    username = data.get('username')
    password = data.get('password')
    
    # For testing, accept any non-empty username and password
    if username and password:
        return JSONResponse({
            'success': True,
            'message': 'Login successful',
            'user': {
                'username': username,
                'role': 'admin'
            }
        })
    else:
        raise HTTPException(status_code=401, detail='Invalid username or password')

# Login endpoint
@app.post("/login")
async def login(credentials: HTTPBasicCredentials = Depends(security)):
    username = get_current_username(credentials)
    return {"username": username, "message": "Login successful"}

# Get user preferences
@app.get("/user/preferences")
async def get_user_preferences(username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        # Check if user_preferences table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'user_preferences'
            )
        """)
        table_exists = cursor.fetchone()['exists']
        
        if not table_exists:
            # Create user_preferences table if it doesn't exist
            cursor.execute("""
                CREATE TABLE user_preferences (
                    username TEXT PRIMARY KEY,
                    columns TEXT[]
                )
            """)
            conn.commit()
        
        # Get user preferences
        cursor.execute("SELECT columns FROM user_preferences WHERE username = %s", (username,))
        result = cursor.fetchone()
        
        if result:
            return {"columns": result['columns']}
        else:
            # Return default columns if no preferences are found
            return {"columns": DEFAULT_COLUMNS}
    except Exception as e:
        print(f"Error getting user preferences: {e}")
        return {"columns": DEFAULT_COLUMNS}
    finally:
        conn.close()

# Update user preferences
@app.post("/user/preferences")
async def update_user_preferences(preferences: Dict[str, List[str]], username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Check if user_preferences table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'user_preferences'
            )
        """)
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            # Create user_preferences table if it doesn't exist
            cursor.execute("""
                CREATE TABLE user_preferences (
                    username TEXT PRIMARY KEY,
                    columns TEXT[]
                )
            """)
        
        # Upsert user preferences
        cursor.execute("""
            INSERT INTO user_preferences (username, columns)
            VALUES (%s, %s)
            ON CONFLICT (username) 
            DO UPDATE SET columns = EXCLUDED.columns
        """, (username, preferences["columns"]))
        
        conn.commit()
        return {"message": "Preferences updated successfully"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating preferences: {str(e)}")
    finally:
        conn.close()

# Get all column names
@app.get("/columns")
async def get_columns(username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Check if tracker table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'tracker'
            )
        """)
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            # Create a sample tracker table with minimal columns for testing
            cursor.execute("""
                CREATE TABLE tracker (
                    "SITE_ID" TEXT PRIMARY KEY,
                    "Site Name" TEXT,
                    "DISTRICT_COMMUNITY" TEXT,
                    "City/Road" TEXT,
                    "Economical Region" TEXT,
                    "Lat" NUMERIC,
                    "Long" NUMERIC,
                    "Planning Status" TEXT
                )
            """)
            conn.commit()
            
            # Insert some sample data
            sample_data = [
                ('SITE001', 'Alpha Site', 'District A', 'Main Road', 'North', 40.7128, -74.0060, 'Active'),
                ('SITE002', 'Beta Site', 'District B', 'Secondary Road', 'South', 34.0522, -118.2437, 'Planning'),
                ('SITE003', 'Gamma Site', 'District C', 'Highway 1', 'East', 41.8781, -87.6298, 'Construction'),
                ('SITE004', 'Delta Site', 'District A', 'Avenue X', 'West', 29.7604, -95.3698, 'Active'),
                ('SITE005', 'Epsilon Site', 'District D', 'Boulevard Y', 'Central', 39.9526, -75.1652, 'Maintenance')
            ]
            
            cursor.executemany("""
                INSERT INTO tracker ("SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status")
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, sample_data)
            conn.commit()
        
        cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'tracker' ORDER BY ordinal_position")
        columns = [row[0] for row in cursor.fetchall()]
        return {"columns": columns}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching columns: {str(e)}")
    finally:
        conn.close()

# Get paginated data
@app.get("/data")
async def get_data(offset: int = 0, limit: int = 50, columns: Optional[str] = None, search: Optional[str] = None, username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        # Determine which columns to fetch
        if columns:
            column_list = columns.split(",")
        else:
            # Get user preferences
            cursor.execute("SELECT columns FROM user_preferences WHERE username = %s", (username,))
            result = cursor.fetchone()
            
            if result:
                column_list = result['columns']
            else:
                column_list = DEFAULT_COLUMNS
        
        # Ensure we always include SITE_ID for reference
        if "SITE_ID" not in column_list:
            column_list.insert(0, "SITE_ID")
        
        columns_sql = ", ".join(f'"{col}"' for col in column_list)
        
        # Build the query
        query = f'SELECT {columns_sql} FROM tracker'
        params = []
        
        # Add search condition if provided
        if search:
            search_conditions = []
            for col in column_list:
                search_conditions.append(f'"{col}"::text ILIKE %s')
                params.append(f'%{search}%')
            
            query += " WHERE " + " OR ".join(search_conditions)
        
        # Add pagination
        query += " ORDER BY \"SITE_ID\" LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        
        cursor.execute(query, params)
        data = cursor.fetchall()
        
        # Get total count for pagination info
        cursor.execute("SELECT COUNT(*) FROM tracker")
        total = cursor.fetchone()["count"]
        
        return {
            "data": data,
            "total": total,
            "offset": offset,
            "limit": limit,
            "has_more": offset + limit < total
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching data: {str(e)}")
    finally:
        conn.close()

# Get all data (for expanding row details)
@app.get("/data/all")
async def get_all_data(site_id: str, username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute('SELECT * FROM tracker WHERE "SITE_ID" = %s', (site_id,))
        data = cursor.fetchone()
        
        if not data:
            raise HTTPException(status_code=404, detail=f"Site with ID {site_id} not found")
        
        return data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching data: {str(e)}")
    finally:
        conn.close()

# Edit data
@app.post("/data/edit")
async def edit_data(data: Dict[str, Dict[str, Any]], username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Begin transaction
        conn.autocommit = False
        
        for site_id, updates in data.items():
            # Build SET clause for UPDATE statement
            set_clause = ", ".join([f'"{col}" = %s' for col in updates.keys()])
            values = list(updates.values())
            values.append(site_id)  # For the WHERE clause
            
            query = f'UPDATE tracker SET {set_clause} WHERE "SITE_ID" = %s'
            cursor.execute(query, values)
        
        # Commit transaction
        conn.commit()
        
        return {"message": "Data updated successfully"}
    except Exception as e:
        # Rollback in case of error
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating data: {str(e)}")
    finally:
        conn.autocommit = True
        conn.close()

# Import data from Excel
@app.post("/data/import")
async def import_data(file: UploadFile = File(...), username: str = Depends(get_current_username)):
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are allowed")
    
    try:
        # Read Excel file
        contents = await file.read()
        df = pd.read_excel(BytesIO(contents))
        
        # Ensure SITE_ID column exists
        if "SITE_ID" not in df.columns:
            raise HTTPException(status_code=400, detail="Excel file must contain a SITE_ID column")
        
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            
            # Begin transaction
            conn.autocommit = False
            
            # Get existing columns from database
            cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'tracker'")
            db_columns = [row[0] for row in cursor.fetchall()]
            
            # Filter dataframe to only include columns that exist in the database
            valid_columns = [col for col in df.columns if col in db_columns]
            df_filtered = df[valid_columns]
            
            # Process each row
            for _, row in df_filtered.iterrows():
                site_id = row["SITE_ID"]
                
                # Check if the site exists
                cursor.execute('SELECT 1 FROM tracker WHERE "SITE_ID" = %s', (site_id,))
                site_exists = cursor.fetchone() is not None
                
                # Convert row to dict and handle NaN values
                row_dict = row.to_dict()
                for k, v in row_dict.items():
                    if pd.isna(v):
                        row_dict[k] = None
                
                if site_exists:
                    # Update existing site
                    set_clause = ", ".join([f'"{col}" = %s' for col in valid_columns if col != "SITE_ID"])
                    values = [row_dict[col] for col in valid_columns if col != "SITE_ID"]
                    values.append(site_id)  # For the WHERE clause
                    
                    if set_clause:  # Only proceed if there are columns to update
                        query = f'UPDATE tracker SET {set_clause} WHERE "SITE_ID" = %s'
                        cursor.execute(query, values)
                else:
                    # Insert new site
                    columns = ", ".join([f'"{col}"' for col in valid_columns])
                    placeholders = ", ".join(["%s"] * len(valid_columns))
                    values = [row_dict[col] for col in valid_columns]
                    
                    query = f'INSERT INTO tracker ({columns}) VALUES ({placeholders})'
                    cursor.execute(query, values)
            
            # Commit transaction
            conn.commit()
            
            return {"message": f"Successfully imported {len(df)} rows"}
        except Exception as e:
            # Rollback in case of error
            conn.rollback()
            raise HTTPException(status_code=500, detail=f"Error importing data: {str(e)}")
        finally:
            conn.autocommit = True
            conn.close()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")

# Export data to Excel
@app.get("/data/export")
async def export_data(columns: Optional[str] = None, search: Optional[str] = None, username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        # Determine which columns to fetch
        if columns:
            column_list = columns.split(",")
        else:
            # Get all columns for export
            cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'tracker' ORDER BY ordinal_position")
            column_list = [row["column_name"] for row in cursor.fetchall()]
        
        columns_sql = ", ".join(f'"{col}"' for col in column_list)
        
        # Build the query
        query = f'SELECT {columns_sql} FROM tracker'
        params = []
        
        # Add search condition if provided
        if search:
            search_conditions = []
            for col in column_list:
                search_conditions.append(f'"{col}"::text ILIKE %s')
                params.append(f'%{search}%')
            
            query += " WHERE " + " OR ".join(search_conditions)
        
        cursor.execute(query, params)
        data = cursor.fetchall()
        
        # Convert to DataFrame and export to Excel
        df = pd.DataFrame(data)
        
        # Create a BytesIO object to store the Excel file
        output = BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Data')
        
        # Generate a unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"data_export_{timestamp}.xlsx"
        
        # Create exports directory if it doesn't exist
        os.makedirs("static/exports", exist_ok=True)
        
        # Create the Excel file on disk
        output.seek(0)
        with open(f"static/exports/{filename}", "wb") as f:
            f.write(output.getvalue())
        
        # Return the download URL
        return {"download_url": f"/static/exports/{filename}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting data: {str(e)}")
    finally:
        conn.close()

# Add a new site
@app.post("/data/add")
async def add_site(site_data: Dict[str, Any], username: str = Depends(get_current_username)):
    if "SITE_ID" not in site_data:
        raise HTTPException(status_code=400, detail="SITE_ID is required")
    
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Check if site already exists
        cursor.execute('SELECT 1 FROM tracker WHERE "SITE_ID" = %s', (site_data["SITE_ID"],))
        if cursor.fetchone():
            raise HTTPException(status_code=400, detail=f"Site with ID {site_data['SITE_ID']} already exists")
        
        # Insert new site
        columns = ", ".join([f'"{col}"' for col in site_data.keys()])
        placeholders = ", ".join(["%s"] * len(site_data))
        values = list(site_data.values())
        
        query = f'INSERT INTO tracker ({columns}) VALUES ({placeholders})'
        cursor.execute(query, values)
        conn.commit()
        
        return {"message": "Site added successfully"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Error adding site: {str(e)}")
    finally:
        conn.close()

# Delete a site
@app.delete("/data/delete/{site_id}")
async def delete_site(site_id: str, username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Check if site exists
        cursor.execute('SELECT 1 FROM tracker WHERE "SITE_ID" = %s', (site_id,))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail=f"Site with ID {site_id} not found")
        
        # Delete site
        cursor.execute('DELETE FROM tracker WHERE "SITE_ID" = %s', (site_id,))
        conn.commit()
        
        return {"message": f"Site {site_id} deleted successfully"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting site: {str(e)}")
    finally:
        conn.close()

# Get statistics
@app.get("/stats")
async def get_stats(username: str = Depends(get_current_username)):
    conn = get_db_connection()
    try:
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        
        # Get total count
        cursor.execute("SELECT COUNT(*) as total FROM tracker")
        total = cursor.fetchone()["total"]
        
        # Get counts by planning status
        cursor.execute("""
            SELECT "Planning Status", COUNT(*) as count 
            FROM tracker 
            GROUP BY "Planning Status"
        """)
        status_counts = cursor.fetchall()
        
        # Get counts by region
        cursor.execute("""
            SELECT "Economical Region", COUNT(*) as count 
            FROM tracker 
            GROUP BY "Economical Region"
        """)
        region_counts = cursor.fetchall()
        
        return {
            "total_sites": total,
            "by_status": status_counts,
            "by_region": region_counts
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching statistics: {str(e)}")
    finally:
        conn.close()

# Initialize database tables if they don't exist
@app.on_event("startup")
async def startup_event():
    # Create exports directory if it doesn't exist
    os.makedirs("static/exports", exist_ok=True)
    
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        
        # Check if user_preferences table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'user_preferences'
            )
        """)
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            # Create user_preferences table
            cursor.execute("""
                CREATE TABLE user_preferences (
                    username TEXT PRIMARY KEY,
                    columns TEXT[]
                )
            """)
            conn.commit()
            print("Created user_preferences table")
        
        # Check if tracker table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = 'tracker'
            )
        """)
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            # Create a minimal tracker table for testing
            cursor.execute("""
                CREATE TABLE tracker (
                    "SITE_ID" TEXT PRIMARY KEY,
                    "Site Name" TEXT,
                    "DISTRICT_COMMUNITY" TEXT,
                    "City/Road" TEXT,
                    "Economical Region" TEXT,
                    "Lat" NUMERIC,
                    "Long" NUMERIC,
                    "Planning Status" TEXT
                )
            """)
            conn.commit()
            
            # Insert some sample data
            sample_data = [
                ('SITE001', 'Alpha Site', 'District A', 'Main Road', 'North', 40.7128, -74.0060, 'Active'),
                ('SITE002', 'Beta Site', 'District B', 'Secondary Road', 'South', 34.0522, -118.2437, 'Planning'),
                ('SITE003', 'Gamma Site', 'District C', 'Highway 1', 'East', 41.8781, -87.6298, 'Construction'),
                ('SITE004', 'Delta Site', 'District A', 'Avenue X', 'West', 29.7604, -95.3698, 'Active'),
                ('SITE005', 'Epsilon Site', 'District D', 'Boulevard Y', 'Central', 39.9526, -75.1652, 'Maintenance')
            ]
            
            cursor.executemany("""
                INSERT INTO tracker ("SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status")
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, sample_data)
            conn.commit()
            print("Created tracker table with sample data")
    except Exception as e:
        print(f"Error initializing database: {e}")
    finally:
        conn.close()

# Run the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)