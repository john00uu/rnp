// Dashboard functionality
document.addEventListener('DOMContentLoaded', () => {
    // Dashboard collapse/expand functionality
    const dashboard = document.getElementById('dashboard');
    const dashboardHeader = document.querySelector('.dashboard-header');

    if (dashboard && dashboardHeader) {
        dashboardHeader.addEventListener('click', (e) => {
            // Only toggle if clicking directly on the header (not on buttons inside it)
            if (e.target === dashboardHeader || e.target.tagName === 'H2') {
                dashboard.classList.toggle('collapsed');
            }
        });
    }

    // Initialize charts when data is available
    window.initializeCharts = (statusData, regionData) => {
        updateStatusChart(statusData);
        updateRegionChart(regionData);
    };

    // Status chart
    function updateStatusChart(statusData) {
        const ctx = document.getElementById('status-chart');
        if (!ctx) return;

        const labels = statusData.map(item => item["Planning Status"]);
        const data = statusData.map(item => item.count);
        const colors = getChartColors(statusData.length);

        if (window.statusChart) {
            window.statusChart.destroy();
        }

        window.statusChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: colors,
                    borderColor: isDarkMode() ? '#1e293b' : '#ffffff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            color: isDarkMode() ? '#e2e8f0' : '#334155',
                            font: {
                                size: 12
                            },
                            padding: 20
                        }
                    },
                    tooltip: {
                        backgroundColor: isDarkMode() ? '#1e293b' : '#ffffff',
                        titleColor: isDarkMode() ? '#e2e8f0' : '#334155',
                        bodyColor: isDarkMode() ? '#e2e8f0' : '#334155',
                        borderColor: isDarkMode() ? '#334155' : '#e2e8f0',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                },
                animation: {
                    animateScale: true,
                    animateRotate: true
                }
            }
        });
    }

    // Region chart
    function updateRegionChart(regionData) {
        const ctx = document.getElementById('region-chart');
        if (!ctx) return;

        const labels = regionData.map(item => item["Economical Region"]);
        const data = regionData.map(item => item.count);
        const colors = getChartColors(regionData.length);

        if (window.regionChart) {
            window.regionChart.destroy();
        }

        window.regionChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Number of Sites',
                    data: data,
                    backgroundColor: colors,
                    borderColor: isDarkMode() ? '#1e293b' : '#ffffff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: isDarkMode() ? '#1e293b' : '#ffffff',
                        titleColor: isDarkMode() ? '#e2e8f0' : '#334155',
                        bodyColor: isDarkMode() ? '#e2e8f0' : '#334155',
                        borderColor: isDarkMode() ? '#334155' : '#e2e8f0',
                        borderWidth: 1,
                        padding: 12
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false,
                            color: isDarkMode() ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            color: isDarkMode() ? '#e2e8f0' : '#334155'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: isDarkMode() ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            color: isDarkMode() ? '#e2e8f0' : '#334155'
                        }
                    }
                },
                animation: {
                    duration: 1000
                }
            }
        });
    }

    // Helper function to get chart colors
    function getChartColors(count) {
        const colors = [
            '#00ff9d', '#00cc7d', '#0066ff', '#3399ff', 
            '#66ccff', '#99ffcc', '#ccffee'
        ];
        
        const result = [];
        for (let i = 0; i < count; i++) {
            result.push(colors[i % colors.length]);
        }
        
        return result;
    }

    // Helper function to check dark mode
    function isDarkMode() {
        return document.body.classList.contains('dark');
    }
});