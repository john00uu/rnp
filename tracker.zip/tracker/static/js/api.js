// API Service
const api = {
    // Authentication
    // login: async (username, password) => {
    //     // For demo purposes, we'll use a simple check
    //     // In a real app, this would be a fetch to your backend
    //     return new Promise((resolve, reject) => {
    //         setTimeout(() => {
    //             // Accept any username/password for demo
    //             if (username && password) {
    //                 resolve({ username: username });
    //             } else {
    //                 reject(new Error('Invalid credentials'));
    //             }
    //         }, 500);
    //     });
    // },

    // Data fetching
    getData: async (params) => {
        // Mock data for demonstration
        return new Promise((resolve) => {
            setTimeout(() => {
                const data = [];
                for (let i = 0; i < params.limit; i++) {
                    const index = params.offset + i;
                    data.push({
                        SITE_ID: `SITE-${index}`,
                        "Site Name": `Site ${index}`,
                        DISTRICT_COMMUNITY: `District ${index}`,
                        "City/Road": `City ${index}`,
                        "Economical Region": `Region ${index % 5}`,
                        Lat: 40.7128 + (index * 0.001),
                        Long: -74.0060 + (index * 0.001),
                        "Planning Status": index % 3 === 0 ? "Active" : (index % 3 === 1 ? "Inactive" : "Construction")
                    });
                }
                resolve({ 
                    data: data, 
                    has_more: params.offset + params.limit < 200 
                });
            }, 500);
        });
    },

    // Get statistics
    getStats: async () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    total_sites: 187,
                    by_status: [
                        { "Planning Status": "Active", count: 95 },
                        { "Planning Status": "Inactive", count: 62 },
                        { "Planning Status": "Construction", count: 30 }
                    ],
                    by_region: [
                        { "Economical Region": "Region 0", count: 42 },
                        { "Economical Region": "Region 1", count: 35 },
                        { "Economical Region": "Region 2", count: 48 },
                        { "Economical Region": "Region 3", count: 37 },
                        { "Economical Region": "Region 4", count: 25 }
                    ]
                });
            }, 500);
        });
    },

    // Get all columns
    getColumns: async () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    columns: [
                        "SITE_ID", 
                        "Site Name", 
                        "DISTRICT_COMMUNITY", 
                        "City/Road", 
                        "Economical Region", 
                        "Lat", 
                        "Long", 
                        "Planning Status",
                        "Construction Date",
                        "Activation Date",
                        "Maintenance Schedule",
                        "Last Inspection",
                        "Responsible Engineer",
                        "Power Supply",
                        "Network Type",
                        "Coverage Area"
                    ]
                });
            }, 300);
        });
    },

    // Get user preferences
    getUserPreferences: async () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                // Check if we have saved preferences in localStorage
                const savedPrefs = localStorage.getItem('userColumnPreferences');
                if (savedPrefs) {
                    resolve({ columns: JSON.parse(savedPrefs) });
                } else {
                    // Default columns
                    resolve({ 
                        columns: ["SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status"]
                    });
                }
            }, 300);
        });
    },

    // Save user preferences
    saveUserPreferences: async (preferences) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                // Save to localStorage for demo
                localStorage.setItem('userColumnPreferences', JSON.stringify(preferences.columns));
                resolve({ success: true });
            }, 300);
        });
    },

    // Get detailed site data
    getSiteDetails: async (siteId) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                // Generate detailed data for the site
                const siteIndex = parseInt(siteId.split('-')[1]);
                resolve({
                    SITE_ID: siteId,
                    "Site Name": `Site ${siteIndex}`,
                    "DISTRICT_COMMUNITY": `District ${siteIndex}`,
                    "City/Road": `City ${siteIndex}`,
                    "Economical Region": `Region ${siteIndex % 5}`,
                    "Lat": 40.7128 + (siteIndex * 0.001),
                    "Long": -74.0060 + (siteIndex * 0.001),
                    "Planning Status": siteIndex % 3 === 0 ? "Active" : (siteIndex % 3 === 1 ? "Inactive" : "Construction"),
                    "Construction Date": "2023-01-15",
                    "Activation Date": "2023-03-20",
                    "Maintenance Schedule": "Quarterly",
                    "Last Inspection": "2023-09-10",
                    "Responsible Engineer": `Engineer ${siteIndex % 10}`,
                    "Power Supply": "Main Grid + Backup Generator",
                    "Network Type": "4G/5G",
                    "Coverage Area": "15km radius"
                });
            }, 500);
        });
    }
};