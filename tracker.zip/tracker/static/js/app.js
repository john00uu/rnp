// Declare variables
let visibleColumns = [];
let tableHeader = document.getElementById('table-header');
let tableBody = document.getElementById('table-body');
let currentData = [];

// Declare missing variables
let showLoading;
let currentUser;
let showNotification;
let loadInitialData;

// Update the renderTableHeaders function
function renderTableHeaders() {
    console.log("Rendering table headers for columns:", visibleColumns);
    
    if (!tableHeader) {
        console.error("tableHeader element not found");
        return;
    }
    
    tableHeader.innerHTML = '';
    
    // Ensure visibleColumns is an array
    if (!Array.isArray(visibleColumns) || visibleColumns.length === 0) {
        console.log("No visible columns, using defaults");
        visibleColumns = ["SITE_ID", "Site Name", "DISTRICT_COMMUNITY", "City/Road", "Economical Region", "Lat", "Long", "Planning Status"];
    }

    // Add headers for visible columns
    visibleColumns.forEach(column => {
        const th = document.createElement('th');
        th.textContent = column;
        
        // Add sort icon
        const sortIcon = document.createElement('i');
        sortIcon.className = 'fas fa-sort ml-2';
        sortIcon.style.marginLeft = '0.5rem';
        sortIcon.style.opacity = '0.5';
        th.appendChild(sortIcon);
        
        tableHeader.appendChild(th);
    });

    // Add actions column
    const actionsHeader = document.createElement('th');
    actionsHeader.textContent = 'Actions';
    actionsHeader.style.width = '80px';
    tableHeader.appendChild(actionsHeader);
    
    console.log("Table headers rendered");
}

// Update the renderTableData function
function renderTableData(data) {
    console.log("Rendering table data:", data);
    
    if (!tableBody) {
        console.error("tableBody element not found");
        return;
    }
    
    if (!Array.isArray(data)) {
        console.error("Data is not an array:", data);
        return;
    }
    
    // Add new data to the current data array
    currentData = [...currentData, ...data];

    // Render each row
    data.forEach(row => {
        const tr = document.createElement('tr');
        tr.dataset.siteId = row.SITE_ID;
        tr.className = 'animate__animated animate__fadeIn';
        
        // Add cells for visible columns
        visibleColumns.forEach(column => {
            const td = document.createElement('td');
            td.textContent = row[column] !== undefined && row[column] !== null ? row[column] : '';
            td.classList.add('editable');
            td.dataset.column = column;
            td.addEventListener('click', () => {
                toggleCellEditMode(td);
            });
            tr.appendChild(td);
        });
        
        // Add actions cell
        const actionsCell = document.createElement('td');
        actionsCell.classList.add('row-actions');
        
        const detailsBtn = document.createElement('button');
        detailsBtn.innerHTML = '<i class="fas fa-ellipsis-h"></i>';
        detailsBtn.title = 'View Details';
        detailsBtn.className = 'ripple';
        detailsBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent row click
            showRowDetails(row.SITE_ID);
        });
        
        actionsCell.appendChild(detailsBtn);
        tr.appendChild(actionsCell);
        
        tableBody.appendChild(tr);
    });
    
    console.log("Table data rendered");
}

// Fix for the login function only - add this to your existing code
async function handleLogin(e) {
    e.preventDefault();
    console.log("Login form submitted");

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    console.log("Username:", username);
    console.log("Password:", password ? "Provided" : "Not provided");

    try {
        // Show loading if the function exists
        if (typeof showLoading === 'function') {
            showLoading(true);
        }
        
        // Accept any non-empty username and password
        if (username && password) {
            console.log("Login successful, setting currentUser to:", username);
            
            // Store user in session
            currentUser = username;
            sessionStorage.setItem('currentUser', username);
            
            // Show success notification if the function exists
            if (typeof showNotification === 'function') {
                showNotification('Login successful!', 'success');
            }
            
            console.log("Transitioning to main page...");
            
            // Get the login and main page elements
            const loginPage = document.getElementById('login-page');
            const mainPage = document.getElementById('main-page');
            
            if (loginPage && mainPage) {
                // IMPORTANT: Force hide login page and show main page immediately
                loginPage.classList.add('hidden');
                mainPage.classList.remove('hidden');
                
                // Set username display if the element exists
                const usernameDisplay = document.getElementById('username-display');
                if (usernameDisplay) {
                    usernameDisplay.textContent = username;
                }
                
                // Load initial data if the function exists
                if (typeof loadInitialData === 'function') {
                    loadInitialData();
                }
            } else {
                console.error("Login or main page elements not found:", { loginPage, mainPage });
            }
        } else {
            throw new Error('Please enter both username and password');
        }
    } catch (error) {
        console.error("Login error:", error);
        
        // Show error message if the element exists
        const loginError = document.getElementById('login-error');
        if (loginError) {
            loginError.textContent = error.message || 'Invalid username or password';
            loginError.classList.add('animate__animated', 'animate__shakeX');
            setTimeout(() => {
                loginError.classList.remove('animate__animated', 'animate__shakeX');
            }, 1000);
        }
    } finally {
        // Hide loading if the function exists
        if (typeof showLoading === 'function') {
            showLoading(false);
        }
    }
}

// Add a direct click handler to the login button
document.addEventListener('DOMContentLoaded', function() {
    const loginButton = document.querySelector('.login-btn');
    if (loginButton) {
        console.log("Adding click handler to login button");
        loginButton.addEventListener('click', function(e) {
            // Only handle the click if it's not already handled by the form
            if (!e.target.closest('form') || !e.target.closest('form').checkValidity()) {
                e.preventDefault();
                handleLogin(e);
            }
        });
    } else {
        console.error("Login button not found");
    }
    
    // Also add submit handler to the login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        console.log("Adding submit handler to login form");
        loginForm.addEventListener('submit', handleLogin);
    } else {
        console.error("Login form not found");
    }
});

// Dummy function for toggleCellEditMode
function toggleCellEditMode(td) {
    console.log("toggleCellEditMode called for:", td);
}

// Dummy function for showRowDetails
function showRowDetails(siteId) {
    console.log("showRowDetails called for siteId:", siteId);
}

// Add this function to debug table rendering issues
function debugTableRendering() {
    console.log("Debugging table rendering...");
    
    // Check if table elements exist
    const tableHeader = document.getElementById('table-header');
    const tableBody = document.getElementById('table-body');
    
    console.log("Table header element:", tableHeader);
    console.log("Table body element:", tableBody);
    
    if (!tableHeader || !tableBody) {
        console.error("Table elements not found. Check your HTML for elements with IDs 'table-header' and 'table-body'");
        
        // Try alternative selectors
        const altTableHeader = document.querySelector('thead tr');
        const altTableBody = document.querySelector('tbody');
        
        console.log("Alternative table header element:", altTableHeader);
        console.log("Alternative table body element:", altTableBody);
        
        if (altTableHeader && altTableBody) {
            console.log("Found alternative table elements. Consider using these selectors instead.");
        }
    }
    
    // Check if data is being loaded
    console.log("Current data array:", currentData);
    
    // Check if visible columns are defined
    console.log("Visible columns:", visibleColumns);
    
    // Check CSS for hidden elements
    const tableWrapper = document.querySelector('.table-wrapper');
    if (tableWrapper) {
        const computedStyle = window.getComputedStyle(tableWrapper);
        console.log("Table wrapper display:", computedStyle.display);
        console.log("Table wrapper visibility:", computedStyle.visibility);
        console.log("Table wrapper height:", computedStyle.height);
        
        if (computedStyle.display === 'none' || computedStyle.visibility === 'hidden' || computedStyle.height === '0px') {
            console.error("Table wrapper is hidden by CSS");
        }
    }
}

// Call this function after login
document.addEventListener('DOMContentLoaded', function() {
    const loginButton = document.querySelector('.login-btn');
    if (loginButton) {
        console.log("Adding click handler to login button");
        loginButton.addEventListener('click', function(e) {
            // Only handle the click if it's not already handled by the form
            if (!e.target.closest('form') || !e.target.closest('form').checkValidity()) {
                e.preventDefault();
                handleLogin(e);
            }
        });
    } else {
        console.error("Login button not found");
    }
    
    // Also add submit handler to the login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        console.log("Adding submit handler to login form");
        loginForm.addEventListener('submit', handleLogin);
    } else {
        console.error("Login form not found");
    }
    // Add a button to trigger debugging
    const mainPage = document.getElementById('main-page');
    if (mainPage) {
        const debugButton = document.createElement('button');
        debugButton.textContent = "Debug Table";
        debugButton.style.position = "fixed";
        debugButton.style.bottom = "10px";
        debugButton.style.right = "10px";
        debugButton.style.zIndex = "9999";
        debugButton.style.padding = "10px";
        debugButton.style.backgroundColor = "#ff5722";
        debugButton.style.color = "white";
        debugButton.style.border = "none";
        debugButton.style.borderRadius = "4px";
        debugButton.style.cursor = "pointer";
        
        debugButton.addEventListener('click', function() {
            debugTableRendering();
            
            // Force render mock data
            const mockData = Array.from({ length: 10 }, (_, i) => ({
                SITE_ID: `SITE-${i + 1}`,
                "Site Name": `Site ${i + 1}`,
                "DISTRICT_COMMUNITY": `District ${i % 5 + 1}`,
                "City/Road": `Road ${i % 10 + 1}`,
                "Economical Region": `Region ${i % 3 + 1}`,
                "Lat": 34.0522 + (i * 0.01),
                "Long": -118.2437 + (i * 0.01),
                "Planning Status": ["Active", "Inactive", "Construction"][i % 3]
            }));
            
            console.log("Forcing render of mock data:", mockData);
            
            // Try to find the table body with different selectors
            const tableBody = document.getElementById('table-body') || document.querySelector('tbody');
            
            if (tableBody) {
                // Clear existing data
                tableBody.innerHTML = '';
                
                // Render mock data
                mockData.forEach(row => {
                    const tr = document.createElement('tr');
                    
                    // Add cells for each column
                    Object.entries(row).forEach(([key, value]) => {
                        const td = document.createElement('td');
                        td.textContent = value;
                        tr.appendChild(td);
                    });
                    
                    // Add actions cell
                    const actionsCell = document.createElement('td');
                    actionsCell.innerHTML = '<button>View</button>';
                    tr.appendChild(actionsCell);
                    
                    tableBody.appendChild(tr);
                });
                
                console.log("Mock data rendered to table");
            } else {
                console.error("Could not find table body element with any selector");
                
                // Create a new table as a last resort
                const newTable = document.createElement('table');
                newTable.style.width = "100%";
                newTable.style.borderCollapse = "collapse";
                newTable.style.marginTop = "20px";
                
                // Create header
                const thead = document.createElement('thead');
                const headerRow = document.createElement('tr');
                
                Object.keys(mockData[0]).forEach(key => {
                    const th = document.createElement('th');
                    th.textContent = key;
                    th.style.padding = "10px";
                    th.style.borderBottom = "1px solid #ddd";
                    th.style.textAlign = "left";
                    headerRow.appendChild(th);
                });
                
                // Add actions header
                const actionsHeader = document.createElement('th');
                actionsHeader.textContent = "Actions";
                actionsHeader.style.padding = "10px";
                actionsHeader.style.borderBottom = "1px solid #ddd";
                actionsHeader.style.textAlign = "left";
                headerRow.appendChild(actionsHeader);
                
                thead.appendChild(headerRow);
                newTable.appendChild(thead);
                
                // Create body
                const tbody = document.createElement('tbody');
                
                mockData.forEach(row => {
                    const tr = document.createElement('tr');
                    
                    Object.values(row).forEach(value => {
                        const td = document.createElement('td');
                        td.textContent = value;
                        td.style.padding = "10px";
                        td.style.borderBottom = "1px solid #ddd";
                        tr.appendChild(td);
                    });
                    
                    // Add actions cell
                    const actionsCell = document.createElement('td');
                    actionsCell.innerHTML = '<button>View</button>';
                    actionsCell.style.padding = "10px";
                    actionsCell.style.borderBottom = "1px solid #ddd";
                    tr.appendChild(actionsCell);
                    
                    tbody.appendChild(tr);
                });
                
                newTable.appendChild(tbody);
                
                // Find a place to add the table
                const tableContainer = document.querySelector('.table-container') || document.querySelector('.table-wrapper') || mainPage;
                
                if (tableContainer) {
                    tableContainer.appendChild(newTable);
                    console.log("Created and added new table as fallback");
                } else {
                    console.error("Could not find any container to add the fallback table");
                }
            }
        });
        
        mainPage.appendChild(debugButton);
    }
});